export interface ThemeSettings {
  /** Any CSS color. Drawn adapted to mode and contrast as --accent-ui. */
  accent: string;
  /** 0.4 – 2. Separation of grays and strength of accent tints. */
  contrast: number;
  /** Corner radius in px. */
  radius: number;
  /** Spacing multiplier, 0.7 – 1.6. */
  space: number;
  /** Base font size in px. */
  fs: number;
  /** A key of `fonts`, or any CSS font-family stack. */
  font: string;
  /** Font for numbers and values. */
  numbers: 'mono' | 'ui';
  /** '' follows the system. */
  mode: '' | 'light' | 'dark';
}

export interface FontInfo { label: string; mono: boolean; google?: boolean }

export const defaults: Readonly<ThemeSettings>;
export const fonts: Readonly<Record<string, FontInfo>>;
export const accents: Readonly<Record<string, string>>;

export function fontStack(font: string): string;
export function googleFontUrl(font: string): string | null;
export function loadFont(font: string, doc?: Document): void;
export function normalize(settings?: Partial<ThemeSettings>): ThemeSettings;
export function applyTheme(settings?: Partial<ThemeSettings>, root?: HTMLElement): ThemeSettings;
export function clearTheme(root?: HTMLElement): void;
export function themeToCSS(settings?: Partial<ThemeSettings>, options?: { all?: boolean }): string;
export function saveTheme(settings: Partial<ThemeSettings>, key?: string): boolean;
export function loadTheme(key?: string): ThemeSettings | null;
