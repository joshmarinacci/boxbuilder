// <theme-tuner> — a drop-in panel for adjusting the theme live.
//
//   import 'tooltheme/tuner';
//   <aside><theme-tuner storage-key="my-app" show-css></theme-tuner></aside>
//
// Attributes
//   storage-key  load saved settings on start and save every change (localStorage)
//   show-css     add a "Your settings" section with Copy CSS / Reset
//   collapsed    start with the panel closed
// Events
//   change       detail = full settings object, fired on every adjustment
// Properties
//   .settings    get or set the current settings

import { defaults, fonts, accents, applyTheme, themeToCSS, saveTheme, loadTheme, normalize } from './index.js';

const STYLE_ID = 'tooltheme-tuner-style';
const STYLE = `@layer tooltheme {
  theme-tuner { display: block; }
  theme-tuner .tt-swatches { display: flex; gap: 6px; flex-wrap: wrap; padding: 2px 0 6px; }
  theme-tuner .tt-swatches button {
    width: 22px; height: 22px; padding: 0; border-radius: 50%;
    background: var(--c); border: 2px solid var(--surface-1); box-shadow: 0 0 0 1px var(--border);
  }
  theme-tuner .tt-swatches button:hover { background: var(--c); }
  theme-tuner .tt-swatches button[aria-pressed="true"] { box-shadow: 0 0 0 2px var(--c); }
  theme-tuner textarea { font-family: var(--font-mono); height: 170px; }
}`;

const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

function fontOptions() {
  const group = mono => Object.entries(fonts).filter(([, f]) => f.mono === mono)
    .map(([k, f]) => `<option value="${esc(k)}">${esc(f.label)}</option>`).join('');
  return `<optgroup label="Monospace">${group(true)}</optgroup><optgroup label="Sans-serif">${group(false)}</optgroup>`;
}

// Safe to import during server-side rendering: no DOM, no registration.
const Base = globalThis.HTMLElement ?? class {};

export class ThemeTuner extends Base {
  #s = { ...defaults };

  get settings() { return { ...this.#s }; }
  set settings(v) { this.#s = normalize(v); if (this.isConnected) this.#sync(); }

  connectedCallback() {
    if (!document.getElementById(STYLE_ID)) {
      const st = document.createElement('style');
      st.id = STYLE_ID; st.textContent = STYLE;
      document.head.prepend(st);
    }
    const key = this.getAttribute('storage-key');
    if (key) this.#s = loadTheme(key) ?? this.#s;
    this.#render();
    this.#sync();
  }

  #render() {
    const open = this.hasAttribute('collapsed') ? '' : ' open';
    this.innerHTML = `
      <details${open}>
        <summary>Theme</summary>
        <label>Accent <input type="color" data-k="accent"><output data-o="accent"></output></label>
        <div class="tt-swatches">
          ${Object.entries(accents).map(([n, c]) => `<button type="button" style="--c:${c}" data-accent="${c}" aria-label="${n}"></button>`).join('')}
        </div>
        <label>Contrast <input type="range" data-k="contrast" min="0.4" max="2" step="0.05"><output data-o="contrast"></output></label>
        <label>Corners <input type="range" data-k="radius" min="0" max="12" step="1"><output data-o="radius"></output></label>
        <label>Spacing <input type="range" data-k="space" min="0.7" max="1.6" step="0.05"><output data-o="space"></output></label>
        <label>Font <select data-k="font">${fontOptions()}</select></label>
        <label>Numbers
          <span role="toolbar" data-seg="numbers">
            <button type="button" data-v="mono">Mono</button><button type="button" data-v="ui">Match font</button>
          </span>
        </label>
        <label>Size <input type="range" data-k="fs" min="10" max="16" step="0.5"><output data-o="fs"></output></label>
        <label>Mode
          <span role="toolbar" data-seg="mode">
            <button type="button" data-v="">Auto</button><button type="button" data-v="light">Light</button><button type="button" data-v="dark">Dark</button>
          </span>
        </label>
      </details>
      ${this.hasAttribute('show-css') ? `
      <details open>
        <summary>Your settings</summary>
        <textarea readonly data-css></textarea>
        <div role="group">
          <button type="submit" data-act="copy">Copy CSS</button>
          <button type="button" data-act="reset">Reset</button>
        </div>
      </details>` : ''}`;

    this.addEventListener('input', e => {
      const k = e.target.dataset.k; if (!k) return;
      const v = e.target.value;
      this.#set(k, e.target.type === 'range' ? +v : v);
    });
    this.addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b) return;
      if (b.dataset.accent) return this.#set('accent', b.dataset.accent);
      const seg = b.closest('[data-seg]');
      if (seg) { e.preventDefault(); return this.#set(seg.dataset.seg, b.dataset.v); }
      if (b.dataset.act === 'reset') { this.#s = { ...defaults }; return this.#commit(); }
      if (b.dataset.act === 'copy') return this.#copy(b);
    });
  }

  #set(k, v) { this.#s[k] = v; this.#commit(); }

  #commit() {
    this.#sync();
    const key = this.getAttribute('storage-key');
    if (key) saveTheme(this.#s, key);
    this.dispatchEvent(new CustomEvent('change', { detail: this.settings, bubbles: true }));
  }

  #sync() {
    const s = this.#s;
    applyTheme(s);
    const q = sel => this.querySelector(sel);
    const qa = sel => this.querySelectorAll(sel);
    for (const el of qa('[data-k]')) el.value = s[el.dataset.k];
    const out = { accent: s.accent, contrast: (+s.contrast).toFixed(2), radius: `${s.radius}px`, space: `${(+s.space).toFixed(2)}×`, fs: `${s.fs}px` };
    for (const el of qa('[data-o]')) el.value = out[el.dataset.o];
    for (const b of qa('[data-accent]')) b.setAttribute('aria-pressed', b.dataset.accent.toLowerCase() === String(s.accent).toLowerCase());
    for (const seg of qa('[data-seg]')) for (const b of seg.querySelectorAll('button')) b.setAttribute('aria-pressed', b.dataset.v === s[seg.dataset.seg]);
    const ta = q('[data-css]'); if (ta) ta.value = themeToCSS(s, { all: true });
  }

  async #copy(b) {
    const ta = this.querySelector('[data-css]');
    try { await navigator.clipboard.writeText(ta.value); b.textContent = 'Copied ✓'; }
    catch { ta.select(); b.textContent = 'Selected — copy it'; }
    setTimeout(() => (b.textContent = 'Copy CSS'), 1500);
  }
}

if (globalThis.customElements && !customElements.get('theme-tuner')) customElements.define('theme-tuner', ThemeTuner);
