// tooltheme — helpers for applying, saving and exporting theme settings.
// Pair with the stylesheet: import "tooltheme/tooltheme.css"

/** Default settings. Every key maps to a CSS variable on :root. */
export const defaults = Object.freeze({
  accent: '#3d8bfd', // --accent   (any CSS color)
  contrast: 1,       // --contrast (0.4 – 2)
  radius: 3,         // --radius   (px)
  space: 1,          // --space    (0.7 – 1.6)
  fs: 12,            // --fs       (px)
  font: 'mono',      // --font-ui  (key of `fonts`, or any CSS font stack)
  numbers: 'mono',   // --font-num ('mono' | 'ui')
  mode: '',          // data-theme ('' = follow system, 'light', 'dark')
});

/** Built-in font choices. `google: true` fonts load from Google Fonts on demand. */
export const fonts = Object.freeze({
  'mono':             { label: 'System mono', mono: true },
  'JetBrains Mono':   { label: 'JetBrains Mono', mono: true, google: true },
  'IBM Plex Mono':    { label: 'IBM Plex Mono', mono: true, google: true },
  'Geist Mono':       { label: 'Geist Mono', mono: true, google: true },
  'Space Mono':       { label: 'Space Mono', mono: true, google: true },
  'Spline Sans Mono': { label: 'Spline Sans Mono', mono: true, google: true },
  'sans':             { label: 'System sans', mono: false },
  'Inter':            { label: 'Inter', mono: false, google: true },
  'IBM Plex Sans':    { label: 'IBM Plex Sans', mono: false, google: true },
  'Geist':            { label: 'Geist', mono: false, google: true },
});

/** Accent presets used by the tuner. */
export const accents = Object.freeze({
  Blue: '#3d8bfd', Orange: '#f08c2e', Violet: '#8b5cf6', Green: '#2fb380',
  Red: '#e5484d', Yellow: '#e8c547', Mono: '#e6e6e6',
});

/** CSS font-family value for a font key (or pass-through for a custom stack). */
export function fontStack(font) {
  if (font === 'mono') return 'var(--font-mono)';
  if (font === 'sans') return 'var(--font-sans)';
  const f = fonts[font];
  if (!f) return font; // custom stack, used as-is
  return `"${font}", ${f.mono ? 'var(--font-mono)' : 'var(--font-sans)'}`;
}

/** Google Fonts stylesheet URL for a built-in Google font, else null. */
export function googleFontUrl(font) {
  if (!fonts[font]?.google) return null;
  return `https://fonts.googleapis.com/css2?family=${font.replace(/ /g, '+')}:wght@400;600&display=swap`;
}

/** Inject the Google Fonts stylesheet for `font` once per document. */
export function loadFont(font, doc = globalThis.document) {
  const url = googleFontUrl(font);
  if (!url || !doc) return;
  if (doc.querySelector(`link[data-tooltheme-font="${font}"]`)) return;
  const link = doc.createElement('link');
  link.rel = 'stylesheet';
  link.href = url;
  link.dataset.toolthemeFont = font;
  doc.head.append(link);
}

/** Fill in missing keys with defaults. */
export function normalize(settings = {}) {
  return { ...defaults, ...settings };
}

/**
 * Apply settings to the page by setting CSS variables on `root`
 * (default: <html>). Missing keys fall back to defaults.
 * Returns the full settings object that was applied.
 */
export function applyTheme(settings = {}, root = globalThis.document?.documentElement) {
  const s = normalize(settings);
  if (!root) return s;
  const st = root.style;
  st.setProperty('--accent', s.accent);
  st.setProperty('--contrast', String(s.contrast));
  st.setProperty('--radius', `${s.radius}px`);
  st.setProperty('--space', String(s.space));
  st.setProperty('--fs', `${s.fs}px`);
  st.setProperty('--font-ui', fontStack(s.font));
  st.setProperty('--font-num', s.numbers === 'ui' ? 'var(--font-ui)' : 'var(--font-mono)');
  if (s.mode) root.dataset.theme = s.mode;
  else delete root.dataset.theme;
  loadFont(s.font, root.ownerDocument);
  return s;
}

/** Remove everything applyTheme set, returning to the stylesheet defaults. */
export function clearTheme(root = globalThis.document?.documentElement) {
  if (!root) return;
  for (const p of ['--accent', '--contrast', '--radius', '--space', '--fs', '--font-ui', '--font-num']) {
    root.style.removeProperty(p);
  }
  delete root.dataset.theme;
}

/**
 * Settings as CSS you can paste into a project stylesheet.
 * Only values that differ from the defaults are written unless `all` is true.
 */
export function themeToCSS(settings = {}, { all = false } = {}) {
  const s = normalize(settings);
  const d = defaults;
  const lines = [];
  const add = (key, prop, val) => { if (all || s[key] !== d[key]) lines.push(`  ${prop}: ${val};`); };
  add('accent', '--accent', s.accent);
  add('contrast', '--contrast', +s.contrast);
  add('radius', '--radius', `${s.radius}px`);
  add('space', '--space', +s.space);
  add('fs', '--fs', `${s.fs}px`);
  add('font', '--font-ui', fontStack(s.font));
  if (all || s.numbers !== d.numbers) lines.push(`  --font-num: ${s.numbers === 'ui' ? 'var(--font-ui)' : 'var(--font-mono)'};`);
  const url = googleFontUrl(s.font);
  let css = url ? `@import url("${url}");\n\n` : '';
  css += `:root {\n${lines.join('\n')}\n}`;
  if (s.mode) css += `\n/* and <html data-theme="${s.mode}"> */`;
  return css;
}

/** Save settings to localStorage. Fails silently where storage is unavailable. */
export function saveTheme(settings, key = 'tooltheme') {
  try { localStorage.setItem(key, JSON.stringify(normalize(settings))); return true; }
  catch { return false; }
}

/** Load settings saved with saveTheme (or null). */
export function loadTheme(key = 'tooltheme') {
  try {
    const raw = localStorage.getItem(key);
    return raw ? normalize(JSON.parse(raw)) : null;
  } catch { return null; }
}
