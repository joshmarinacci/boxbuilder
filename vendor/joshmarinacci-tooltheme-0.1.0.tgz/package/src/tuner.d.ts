import type { ThemeSettings } from './index.js';

export class ThemeTuner extends HTMLElement {
  settings: ThemeSettings;
}

declare global {
  interface HTMLElementTagNameMap { 'theme-tuner': ThemeTuner }
  interface HTMLElementEventMap { change: Event | CustomEvent<ThemeSettings> }
}
