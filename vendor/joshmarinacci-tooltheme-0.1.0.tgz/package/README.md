# tooltheme

A classless CSS theme for **apps and tools** (drawing programs, editors, dashboards), not documents. It's dense, neutral and monospace-first. Light/dark follows the system, and a handful of CSS variables tune the whole look live.

Write plain HTML: `header` / `nav` / `main` / `aside` / `footer` become a full-screen app shell, `details` and `fieldset` become inspector panels, `[role=toolbar]` becomes icon-button rows, and `dialog` / `[popover]` become modals and menus.

## Install

```sh
npm install tooltheme
# or, before publishing, from the packed file:
npm install ./tooltheme-0.1.0.tgz
```

## Use the stylesheet

With a bundler (Vite, webpack, Parcel, esbuild…):

```js
import 'tooltheme/tooltheme.css';
```

Or with a plain `<link>`:

```html
<link rel="stylesheet" href="node_modules/tooltheme/tooltheme.css">
```

Everything lives in `@layer tooltheme`, so any CSS you write overrides it without specificity fights.

## Tune it

Set any of these on `:root`:

```css
:root {
  --accent: #3d8bfd;      /* your brand color; drawn adapted as --accent-ui */
  --contrast: 1;          /* 0.4 soft … 2 high */
  --radius: 3px;          /* corners */
  --space: 1;             /* 0.7 tight … 1.6 roomy */
  --fs: 12px;             /* base font size */
  --font-ui: var(--font-mono);   /* or var(--font-sans), or any stack */
  --font-num: var(--font-mono);  /* numbers and values */
}
```


Force a mode with `<html data-theme="light">` or `"dark"`. Leave it off to follow the system.

> These are read on `:root`. Setting them on an inner element won't re-derive the colors and sizes.

## JavaScript helpers (optional)

```js
import { applyTheme, loadTheme, saveTheme, themeToCSS } from 'tooltheme';

applyTheme({ accent: '#f08c2e', contrast: 1.3, mode: 'dark' }); // sets the variables on <html>
saveTheme(current, 'my-app');       // localStorage
applyTheme(loadTheme('my-app') ?? {});
console.log(themeToCSS(current));   // paste-ready :root { … }
```

Also exported: `defaults`, `fonts`, `accents`, `fontStack()`, `googleFontUrl()`, `loadFont()`, `clearTheme()`, `normalize()`. TypeScript types are included.

## The tuning panel

```js
import 'tooltheme/tuner';
```

```html
<aside>
  <theme-tuner storage-key="my-app" show-css></theme-tuner>
</aside>
```

| Attribute     | Effect |
|---------------|--------|
| `storage-key` | Loads saved settings on start and saves every change |
| `show-css`    | Adds a "Your settings" section with Copy CSS and Reset |
| `collapsed`   | Starts closed |

It fires a `change` event (`event.detail` is the settings), and `.settings` gets or sets the values.

## HTML cheat sheet

| Write | Get |
|---|---|
| `body > header, nav, main, aside, footer` | Menu bar, tool rail, canvas, inspector, status bar |
| `main` without a `canvas` | Scrolling page; each `section` is a card |
| `details > summary` / `fieldset > legend` | Collapsible inspector panel |
| `label` with text, a control and an `output` | A property row |
| `[role=toolbar]` | Quiet icon-button row (vertical inside `nav`) |
| `label [role=toolbar]` | Segmented control |
| `[role=group]` | Row of normal buttons |
| `button[aria-pressed=true]` | Active tool or toggle |
| `button[aria-label]` with just an `svg` | Square icon button |
| `button[type=submit]` | Primary button |
| `button[data-variant=danger]` | Destructive button |
| `input[type=checkbox][role=switch]` | Switch |
| `[role=listbox] > [role=option][aria-selected]` | Selectable list (layers, files) |
| `[popover] > menu` | Dropdown menu |
| `dialog > form > header, …, footer` | Modal with title and action bar |
| `[data-tip="…"]` | Themed tooltip |

Controls grow automatically on touch and pen screens.

## Examples

```sh
npm run dev      # then open http://localhost:5173/examples/
```

- `examples/drawing.html`: a drawing app layout
- `examples/forms.html`: every form control, plus the tuning panel

Both examples share saved settings, so adjustments made in one show up in the other.

## Publishing

```sh
npm login
npm publish            # or: npm publish --access public  for a scoped name
```

If `tooltheme` is taken on npm, rename to a scoped package such as `@yourname/tooltheme` in `package.json`.
